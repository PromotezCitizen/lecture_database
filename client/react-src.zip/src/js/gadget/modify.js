const EXPRESS_URL = 'https://term-express.run.goorm.io'

const ModifyGadget = () => {
	return ( <></>)
}
export default ModifyGadget