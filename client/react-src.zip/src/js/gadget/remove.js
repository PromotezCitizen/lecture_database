const RemoveGadget = () => {
	return ( <></>)
}
export default RemoveGadget